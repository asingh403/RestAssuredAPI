package com.rest.api.post;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.PrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class POSTAPIWithPOJO {

	// Create User
	// POST - URL
	// Request JSON Body -->
	// User Java Class (POJO) --> JSON Object
	// Encapsulation --> Private variables --> public(Getters/Setters)
	// POJO -- Plain Old Java Object --Java Class --> Private Variables -->
	// public(Getters/setters)

	@Test
	public void createUser_With_Pojo_Test() {
		User user = new User("Nisha Dubey", "nisha.Joh454@msn.usa.india", "Female", "Active");

		//Convert pojo to Json -- Serialization
		
		ObjectMapper mapper = new ObjectMapper();
		
		String userJson = null;
		try {
			userJson = mapper.writeValueAsString(user);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		System.out.println(userJson);
		
		RestAssured.baseURI = "https://gorest.co.in";
		given().log().all()
			.contentType(ContentType.JSON)
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
			.body(userJson)
		.when().log().all()
			.post("/public-api/users")
		.then().log().all()
			.assertThat()
				.contentType(ContentType.JSON)
				.statusCode(200)
			.and()
				.body("data.name", equalTo(user.getName()))
				.body("data.email", equalTo(user.getEmail()))
				.body("data.gender", equalTo(user.getGender()))
				.body("data.status", equalTo(user.getStatus()));
		
		
	}

}
