package com.rest.api.post;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.io.File;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

public class POSTBDDAPI {
	
	@Test
	public void tokenPostBDDAPI_JSONSTRING_Test() {
		
		RestAssured.baseURI = "https://restful-booker.herokuapp.com";
		given().log().all()
			.contentType(ContentType.JSON)
			.body("{\"username\" : \"admin\",\"password\" : \"password123\"}")
		.when().log().all()
			.post("/auth")
		.then().log().all()
			.assertThat()
				.statusCode(200);
		
	}
	
	@Test
	public void tokenPostBDDAPI_FILE_TEST() {
		RestAssured.baseURI = "https://restful-booker.herokuapp.com";
		
		
		String tokenID = given().log().all()
			.contentType(ContentType.JSON)
			.body(new File("C:\\Users\\ASHUTOSH SINGH\\eclipse-workspace\\"
					+ "APIRestAssured2020\\src\\test\\java\\DataFiles\\credentials.json"))
		.when().log().all()
			.post("/auth")
		.then().log().all()
//			.assertThat()
//				.statusCode(200);  // here we will capture the TOKEN data
				.extract().path("token");
		
		System.out.println(tokenID);
		Assert.assertNotNull(tokenID);
		
	}
	
	@Test
	public void createUser_Post_API_JSONStringTest() {
		RestAssured.baseURI = "https://gorest.co.in";
		
		given().log().all()
			.contentType(ContentType.JSON)
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
			.body("{\"id\": \"432\",\"name\": \"Ashutosh Sigh\",\"email\": \"ashu123@google.india.com\",\"gender\": \"Male\",\"status\": \"Inactive\"}")
		.when().log().all()
			.post("/public-api/users")
		.then().log().all()
			.assertThat()
				.body("meta.data", equalTo(null));	
	}
	
	
	@Test
	public void createUser_Post_API_FileTest() {
		RestAssured.baseURI = "https://gorest.co.in";
		
		given().log().all()
			.contentType(ContentType.JSON)
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
			.body(new File("C:\\Users\\ASHUTOSH SINGH\\eclipse-workspace\\APIRestAssured2020"
					+ "\\src\\test\\java\\DataFiles\\user.json"))
		.when().log().all()
			.post("/public-api/users")
		.then().log().all()
			.assertThat()
				.body("meta.data", equalTo(null));
			
		
	}
	
	

}
