package com.rest.api.get;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class GETBDDAPI {

	@Test
	public void getAPITest() {

		given().log().all().when().log().all().get("https://ergast.com/api/f1/2017/circuits.json").then().log().all()
				.assertThat().body("MRData.CircuitTable.Circuits.circuitId", hasSize(20));
	}

	@Test
	public void getAPICircuitTest() {

		Response response =

				given().log().all().when().log().all().get("https://ergast.com/api/f1/2017/circuits.json");

		int statusCode = response.getStatusCode();

		System.out.print("api response code :: " + statusCode);
		Assert.assertEquals(statusCode, 200);

		System.out.println(response.prettyPrint());

	}

	@Test
	public void getAPICircuitTest_contentLength_Test() {
		RestAssured.baseURI = "https://ergast.com";

		given().log().all().when().log().all().get("/api/f1/2017/circuits.json").then().log().all().assertThat()
				.statusCode(200).and().contentType(ContentType.JSON).and().header("Content-Length", equalTo("4551"));
	}

	@Test
	public void getJsonAPI_VerifyMD5Value() {
		String paramValue = "test";
		String expectedMD5Value = "098f6bcd4621d373cade4e832627b4f6";

		given().log().all()

				.param("text", paramValue) // ? Ques mark not require to write param will take itself
				.when().log().all().get("http://md5.jsontest.com").then().log().all().assertThat()
				.body("md5", equalTo(expectedMD5Value));
	}

	/**
	 * Nums of Circuit Year Wise 2017 = 20 2016 = 21 1966 = 9
	 */

	@DataProvider(name = "getCircuitYearData")
	public Object[][] getAPICircuitYearInfo() {
		return new Object[][] { { "2017", 20 }, { "2016", 21 }, { "1966", 9 } };
	}

	@Test(dataProvider = "getCircuitYearData")
	public void numberOfCircuitYearTest(String seasonsYear, int circuitNumber) {
		given().log().all().pathParam("raceSeason", seasonsYear).when().log().all()
				.get("https://ergast.com/api/f1/{raceSeason}/circuits.json").then().log().all().assertThat()
				.body("MRData.CircuitTable.Circuits.circuitId", hasSize(circuitNumber));
	}

}
