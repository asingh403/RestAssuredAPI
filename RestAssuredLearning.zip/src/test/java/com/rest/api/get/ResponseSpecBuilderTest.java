package com.rest.api.get;

import io.restassured.RestAssured;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;


public class ResponseSpecBuilderTest {
	
	// t1, t2, t3....tn
	// Status Code = 200 --> 201
	// Content Type
	// Header
	
	
	ResponseSpecBuilder res = new ResponseSpecBuilder();
	ResponseSpecification resSpec_200_OK = res
			.expectContentType(ContentType.JSON)
			.expectStatusCode(200)
			.expectHeader("Server", "nginx")
			.build();

	
	ResponseSpecification resSpec_400_BAD_REQUEST = res
			.expectStatusCode(400)
			.expectHeader("Server", "nginx")
			.build();
	
	ResponseSpecification resSpec_401_AUTH_FAIL = res
			.expectStatusCode(401)
			.expectHeader("Server", "nginx")
			.build();
	

	@Test
	public void ResponseSpecTest() {
		RestAssured.baseURI = "https://gorest.co.in";
		given()
		.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
		.when()
			.get("/public-api/users")
		.then()
			.assertThat()
				.spec(resSpec_200_OK);	
	}
	
	@Test
	public void ResponseSpec_Auth_Fail_Test() {
		RestAssured.baseURI = "https://gorest.co.in";
		given()
		.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf111")
		.when()
			.get("/public-api/users")
		.then()
			.assertThat()
				.spec(resSpec_401_AUTH_FAIL);
	}
	
	
	
	
	
}
