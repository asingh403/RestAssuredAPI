package com.rest.api.authentications;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class OAuth2APITest {
	
	@Test(priority=1)
	public void checkOAuthAPITest() {
		
		RequestSpecification request = RestAssured
			.given()
				.auth()
					.oauth2("c1080dbc58c876788f38a65dcc4c135bdd2f21b1");
		Response response = request.post("http://coop.apps.symfonycasts.com/api/1297/chickens-feed");
		
		System.out.println(response.getStatusCode());
		System.out.println(response.prettyPrint());
	}
	
	//1. Generate a Token at the run time by using token api 
	//2. String tokenID from the response
	//3. hit the next api with this tokenID
	
	@Test(priority=2)
	public void getAuth2TokenAPITest() {
		
		RequestSpecification request =
				RestAssured.given()
					.formParam("client_id", "NOVAPIApp")
					.formParam("client_secret", "33d1de605490de397b066a5f8903611b")
					.formParam("grant_type", "client_credentials");
		
		Response response = request.post("http://coop.apps.symfonycasts.com/token");
		
		System.out.println(response.getStatusCode());
		System.out.println(response.prettyPrint());
		
		String tokenID= response.jsonPath().getString("access_token");
		System.out.println("API tokenID is: "+ tokenID);
		
		
		//feed Chicken API
		RequestSpecification request1 =
				RestAssured.given()
					.auth()
					.oauth2(tokenID);
		
		Response response1 = request.post("http://coop.apps.symfonycasts.com/token");
		
		System.out.println(response1.getStatusCode());
		System.out.println(response1.prettyPrint());
		
	}
	
	@Test(priority = 3)
	public void testNgTest_TC002() {
		System.out.println("TestNg Testing ");
	}
	
}
