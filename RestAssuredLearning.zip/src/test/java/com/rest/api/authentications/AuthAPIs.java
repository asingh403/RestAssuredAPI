package com.rest.api.authentications;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;

public class AuthAPIs {
	// basic auth
	// username & password
	
	@Test(priority =1)
	public void basic_auth_API_Test() {
		given().log().all()
		.auth()
		.preemptive()
			.basic("admin", "admin")
		.when().log().all()
			.get("https://the-internet.herokuapp.com/basic_auth")
		.then().log().all()
			.assertThat()
				.statusCode(200);
	}
	
	/**
	 * OAuth2.0
	 * If you are using
	 * 1). with header : append your token with "Bearer" keyword
	 * 2). with oauth method then no need to add "Bearer", just pass the token value
	 */
	@Test(priority =2)
	public void OAuth2_API_Test() {
		
		given().log().all()
			.auth()
				.oauth2("4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
		.when().log().all()
			.get("https://gorest.co.in/public-api/users/1322")
		.then().log().all()
			 .assertThat()
			 	.statusCode(200);
	}
	
	/**
	 * If we do not want to use OAuth method then we can use .header()
	 */
	
	@Test(priority =3)
	public void OAuth_API_Test_With_AuthHeader() {
		
		RestAssured.baseURI = "https://gorest.co.in";
		
		given().log().all()
			.contentType("application/json")
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
				.when().log().all()
					.get("/public-api/users/1322")
				.then().log().all()
					.statusCode(200)
					.and()
					.header("Server", "nginx");
	}
	
	/**
	 * Two Query Params
	 */
	@Test(priority = 4)
	public void OAuth_API_WithTwoQueryParams_API_Test() {
		
		RestAssured.baseURI = "https://gorest.co.in";
		
		given().log().all()
			.contentType("application/json")
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
			.queryParam("name", "Bhagirathi Bharadwaj")
			.queryParam("email", "bhagirathi_bharadwaj@vandervort-muller.io")
		.when().log().all()
			.get("/public-api/users")
		.then().log().all()
			.statusCode(200)
			.and()
			.header("Server", "nginx");
	}	
}
