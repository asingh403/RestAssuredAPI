package com.rest.api.authentications;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

/**
 * 
 * @author ASHUTOSH SINGH
 * This Request will post the tweet on my behalf by using this POST_REQUEST
 */

public class OAuth1APITest {
	
	@Test
	public void TwitterStatusAPI_OAuth1_Test() {
		RequestSpecification request = 
				RestAssured.given()
					.auth()
					.oauth(
							"NIe0D6ALtu2Eb7ogKTqr0nrta", 
							"jhXubsCaDVsxjBNsG3oKIL9HrTnJEZ1zqz5UwL1U77d8XBWmlY", 
							"163807879-b4IaDdRBBRHtndJMmaAxDbqAcKYJerdcpPYxObVw", 
							"57ZEtl4EvArvnuCbc7zEEWcbIynTNlfFRRRMVJ2OebFEC");
		
		Response response = request.post("https://api.twitter.com/1.1/statuses/update.json?status=Hello this is my Ist Tweet from RestAssured Code API !!");
		System.out.println(response.getStatusCode());
		System.out.println(response.prettyPrint());
	
	}
	
}


