package com.rest.api.put;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import io.restassured.http.ContentType;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rest.api.post.User;

import io.restassured.RestAssured;

public class PUTAPITEST {

	// Create a POST request with Payload

	@Test
	public void update_User_PUT_API_Test() {
		User user = new User("Abhishek Saxena", "abhishek.0103@google.com", "Male", "Inactive");

		// Convert this POJO to JSON -- using JACKSON API - ObjectMapper
		ObjectMapper mapper = new ObjectMapper();
		String userJson = null;

		try {
			userJson = mapper.writeValueAsString(user);
		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}
		System.out.println("POST CAL JSON : "+ userJson);
		
		//Write POST Call
		RestAssured.baseURI = "https://gorest.co.in/";
		
		int userId = given().log().all() //String define 
			.contentType(ContentType.JSON)
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
			.body(userJson)
		.when().log().all()
			.post("/public-api/users/")
		.then().log().all()
			.assertThat()
				.contentType(ContentType.JSON)
				.extract().path("data.id");
		
		System.out.println("User ID is  :::> "+ userId);
		
		
		//call the PUT API
		user.setEmail("Abhishek.sharma453@google.in.us");
		user.setStatus("Inactive");
		
		//Call for the PUT API
		
		String updatedUserJson = null;

		try {
			updatedUserJson = mapper.writeValueAsString(user);
		} catch (JsonProcessingException e) {

			e.printStackTrace();
		}
		
		
		given().log().all()
			.contentType(ContentType.JSON)
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
			.body(updatedUserJson)
		.when().log().all()
			.put("/public-api/users/"+userId)
		.then().log().all()
			.assertThat()
				.contentType(ContentType.JSON)
				.and()
					.body("data.email", equalTo(user.getEmail()))
				.and()
					.body("data.id", equalTo(userId))
				.and()
					.body("data.name", equalTo(user.getName()))
				.and()
					.body("data.status", equalTo(user.getStatus()));
				
				
			
				
			

	}

}