package com.rest.api.delete;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;


public class DeleteAPITest {
	
	@Test
	public void delete_user_API_Test() {
		
		RestAssured.baseURI = "https://gorest.co.in/";
		given().log().all()
			.header("Authorization", "Bearer 4796aea4838ce5487518c706d49cc847b57e4196b52f0921539697e2d44bf060")
		.when().log().all()
			.delete("/public-api/users/1587")
				.then().log().all()
			.assertThat().contentType(ContentType.JSON)
				.and()
					.body("code", equalTo(204));
	}

}
